def welcome(name):
    return f"Bienvenue, {name}, sur l'outil de gestion de projet SSI AQUITAIN"
